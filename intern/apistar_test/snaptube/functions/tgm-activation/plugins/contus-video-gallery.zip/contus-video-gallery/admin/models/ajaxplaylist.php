<?php
/**  
 * Video ajaxplaylist admin model file.
 *
 * @category   Apptha
 * @package    Contus video Gallery
 * @version    3.0
 * @author     Apptha Team <developers@contus.in>
 * @copyright  Copyright (C) 2015 Apptha. All rights reserved.
 * @license    GNU General Public License http://www.gnu.org/copyleft/gpl.html 
 */

/**
 * Checks the AjaxPlaylistModel class 
 * has been defined if starts
 */
    /**
     * AjaxPlaylistModel class starts
     * 
     * @author user
     */ 
    class AjaxPlaylistModel { 
        public function __construct() {}
    }
/** Check AjaxPlaylistModel if ends  */ 
?>