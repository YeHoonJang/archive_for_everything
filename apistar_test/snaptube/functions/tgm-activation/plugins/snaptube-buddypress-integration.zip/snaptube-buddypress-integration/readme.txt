=== WordPress Video Gallery BuddyPress Integration ===
Contributors: Cohhe
Tags: Video Player plugin, video, flash player, flv player, WORDPRESS VIDEO GALLERY, flv player wordpress, hd flv player, youtube plugin, youtube Video Player, high definition Video Player, flash, play flv wordpress, player, Video Plugin, wp flv player, wp flv plugin, flv player 2009,  WORDPRESS VIDEO GALLERY, wp flv, wordpress flv plugin, wp hd flv player, flv player plugin, wordpress flv player
Requires at least: 3.0.1
Tested up to: 3.9
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Add front-end video submission functionality for your website.

== Description ==

Now you can submit videos using front-end video submission form. It also integrates with BuddyPress and your activities will be recorded in BuddyPress timeline.

*Where can I use this?*
Cohhe has released the first fully integrated WordPress Video Gallery theme. Check out <a href="http://cohhe.com/snaptube-layouts/">Snaptube</a>

== Installation ==

1. Install BuddyPress https://buddypress.org/
2. Install and Activate "WordPress Video Gallery BuddyPress Integration" plugin.

Thats it, no additional configuration is required.

== Frequently Asked Questions ==

== Screenshots ==

1. Add video form

== Changelog ==

= 1.0 =
* Initial release